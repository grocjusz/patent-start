PATENT START — Android 8.0 lub nowszy

Autorska aplikacja treningowa do części teoretycznej patentu strzeleckiego.
Wydanie 1.1.0: 17.10.2026. 185 pytań z pięciu działów.
Zakres wszystkich 142 pozycji opublikowanego wykazu PZSS ma autorskie
warianty treningowe, uzasadnienia i źródła. Wykaz nie zawiera wariantów
odpowiedzi ani klucza. Nie gwarantujemy brzmienia przyszłego egzaminu.

FUNKCJE
Nauka działami, sesje mieszane, odpowiedź z pamięci przed pokazaniem
wariantów, błędy, zapisane pytania, indywidualne terminy powtórek,
ocena pewności, statystyki, kopia i przywracanie postępów, jasny/ciemny
wygląd i symulacja zasad egzaminu: 10 pytań, 20 minut, po dwa pytania
z pięciu działów; minimum 9/10 oraz bezbłędne pierwsze cztery odpowiedzi.

AKTUALNOŚĆ
Wbudowana baza ma datę weryfikacji i termin kolejnego przeglądu.
Monitor kontroluje ELI i dokumenty PZSS/ISSF przy uruchomieniu i okresowo
w tle. Android może opóźniać zadania; działanie 24/7 nie jest gwarantowane.
Wykryta zmiana wycofuje zależne pytania. Siedem dni bez potwierdzenia
źródeł także je wstrzymuje. Upływ terminu przeglądu blokuje cały pakiet.
Monitor wykrywa zmianę, nie zastępuje przeglądu prawnego.

Nowe treści są instalowane z podpisanego pliku latest.patentpack.
Aplikacja weryfikuje podpis RSA-SHA256, wersję, strukturę bazy i rewizje.
Zmiana treści pytania wymaga podniesienia jego rewizji. Wyniki starej
rewizji nie liczą się jako opanowanie zmienionej treści.
Adres domyślny: https://grocjusz.github.io/patent-start/latest.patentpack
Kanał działa dopiero po opublikowaniu plików i aktywacji GitHub Pages.
Nie publikuj niezweryfikowanych zmian ani wygenerowanych odpowiedzi
bez sprawdzenia źródeł i dat wejścia w życie.

PRYWATNOŚĆ
Bez logowania, reklam i analityki. Postępy pozostają na urządzeniu.
Kopie postępów zapisuje użytkownik w wybranym miejscu. Odinstalowanie
usuwa dane lokalne. Serwisy odwiedzane przy kontroli źródeł i aktualizacji
mogą rejestrować adres IP. Aplikacja nie wysyła do nich odpowiedzi,
historii nauki ani innych danych o postępach.

KOMPILACJA
Narzędzia: Node.js, JDK 17, Android SDK Platform 35, Build Tools 35.0.0.
Nie wymaga Gradle ani płatnych usług.
Ustaw JAVA_HOME, ANDROID_HOME oraz PATENT_SECRET_DIR na prywatny folder.
W domyślnym układzie projektu skrypty korzystają z lokalnego work/toolchain
oraz work/keys, położonych poza folderem źródłowym.
node tools/test.mjs
node tools/build.mjs

NIE URUCHAMIAJ make-bank.mjs bez plików badawczych: służy do odtworzenia
pierwszej bazy i jej odcisków. Nie wolno odświeżać odcisków po zmianie
źródła bez merytorycznej weryfikacji pytań. Zmiana baseline nie jest
naprawą pytania.

PUBLIKACJA PAKIETU
1. Zweryfikuj zmiany źródłowe, przepisy przejściowe i terminy obowiązywania.
2. Zmień odpowiednie pytania i podnieś ich revision.
3. Podnieś version pakietu, releaseDate i reviewUntil po przeglądzie.
4. Uruchom testy, podpisz: node tools/sign-pack.mjs [bank.json] [plik-wyjściowy].
5. Opublikuj latest.patentpack na hostingu HTTPS. Nie zmieniaj nazwy pliku.
6. Sprawdź pobranie i odrzucenie pakietu z nieprawidłowym podpisem.
7. Przy przeglądzie bez zmian treści nadal podnieś wersję i daty pakietu;
   rewizje niezmienionych pytań pozostają bez zmian.

KLUCZE
Prywatny klucz treści oraz magazyn podpisu APK są przechowywane lokalnie
w work/keys, poza archiwum źródłowym i repozytorium. Należy zachować
ich prywatną kopię zapasową. Utrata klucza APK uniemożliwi zwykłe
aktualizowanie zainstalowanej aplikacji tym samym identyfikatorem.
Repozytorium może zawierać public-key.der; to klucz PUBLICZNY.
Nigdy nie dodawaj prywatnych kluczy, haseł ani kopii postępów do GitHub.

OGRANICZENIA WALIDACJI
Testy logiki nauki i oceny egzaminu, podpisu pakietu oraz interfejsu
w przeglądarce nie zastępują testu na fizycznym telefonie. Weryfikacja
APK przez apksigner potwierdza poprawność podpisu, nie całe działanie
systemu Android. Przed poleganiem na aplikacji sprawdź instalację,
źródła, kopie danych i zachowanie na swoim telefonie.
